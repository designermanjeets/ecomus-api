<?php

namespace App\Enums;

enum RoleEnum:string {
  const ADMIN = 'admin';
  const CONSUMER = 'consumer';
  const VENDOR = 'vendor';
}

